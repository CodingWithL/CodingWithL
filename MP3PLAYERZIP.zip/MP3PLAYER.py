import os
import pygame

def play_mp3(file_path):
    pygame.mixer.init()
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play()

def main():
    mp3_files = [
        {"number": 1, "title": "Amiga Da Minha Mulher - Seu Jorge (Músicas Para Churrasco Vol.1)", "path": "SONGDIRECTORY/Amiga Da Minha Mulher - Seu Jorge (Músicas Para Churrasco Vol.1).mp3"},
        {"number": 2, "title": "Arlindo Cruz - Meu Lugar", "path": "SONGDIRECTORY/Arlindo Cruz - Meu Lugar.mp3"},
        {"number": 3, "title": "Carolina, Carol Bela", "path": "SONGDIRECTORY/Carolina, Carol Bela.mp3"},
        {"number": 4, "title": "Ivy Queen - La Vida Es Así (Video Oficial)", "path": "SONGDIRECTORY/Ivy Queen - La Vida Es Así (Video Oficial).mp3"},
        {"number": 5, "title": "Mina do Condomínio", "path": "SONGDIRECTORY/Mina do Condomínio.mp3"}
    ]

    if not mp3_files:
        print("No MP3 files found.")
        return

    print("MP3 files found:")
    for song in mp3_files:
        print(f"{song['number']}. {song['title']}")

    while True:
        choice = input("Enter the number of the song you want to play (or 'q' to quit): ")
        if choice.lower() == 'q':
            break
        try:
            choice = int(choice)
            selected_song = next((song for song in mp3_files if song["number"] == choice), None)
            if selected_song is None:
                print("Invalid choice. Please enter a number within the range.")
            else:
                print(f"Now playing: {selected_song['title']}")
                play_mp3(selected_song['path'])
        except ValueError:
            print("Invalid input. Please enter a number.")

if __name__ == "__main__":
    main()